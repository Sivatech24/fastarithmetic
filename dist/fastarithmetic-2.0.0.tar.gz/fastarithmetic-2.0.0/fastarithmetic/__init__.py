from fastarithmetic.operations import fast_add, fast_sub, fast_mul, fast_div
